var express = require('express');
var app = express();
var counter = 0;
var BALL_SPEED = 15;
var WIDTH = 1100;
var HEIGHT = 580;
var TANK_INIT_HP = 100;

//Static resources server
app.use(express.static(__dirname + '/www'));

var server = app.listen(process.env.PORT || 8082, function () {
	var port = server.address().port;
	console.log('Server running at port %s', port);
});

var io = require('socket.io')(server);

function GameServer(){
	this.tanks = [];
	this.balls = [];
	this.powerup = [];
	this.lastBallId = 0;
}

GameServer.prototype = {

	addPowerup: function(coolPowerup) {
		this.powerup.push(coolPowerup);
	},
	addTank: function(tank){
		this.tanks.push(tank);
	},

	addBall: function(ball){
		this.balls.push(ball);
	},

	removeTank: function(tankId){
		//Remove tank object
		this.tanks = this.tanks.filter( function(t){return t.id != tankId} );
	},
	
	//Sync tank with new data received from a client
	syncTank: function(newTankData){
		var self = this;
		this.tanks.forEach( function(tank){
			if(tank.id == newTankData.id){
				tank.x = newTankData.x;
				tank.y = newTankData.y;
				tank.baseAngle = newTankData.baseAngle;
				tank.cannonAngle = newTankData.cannonAngle;
				// tank.hp = newTankData.hp;
				self.setHealth(tank, newTankData.hp);
			}
		});
	},

	//The app has absolute control of the balls and their movement
	syncBalls: function(){
		var self = this;
		//Detect when ball is out of bounds
		this.balls.forEach( function(ball){
			self.detectCollision(ball);

			if(ball.x < 0 || ball.x > WIDTH
				|| ball.y < 0 || ball.y > HEIGHT){
				ball.out = true;
			}else{
				ball.fly();
			}
		});
	},
	syncPowerup: function(){
		var self = this;
		//Detect when ball is out of bounds
		this.powerup.forEach( function(coolPowerup){
			self.detectCollision2(coolPowerup);

		});
	},
	
	detectCollision2: function(coolPowerup){
		var self = this;

		this.tanks.forEach( function(tank){
			if(
				Math.abs(tank.x - coolPowerup.x) < 30
				&& Math.abs(tank.y - coolPowerup.y) < 30){
				//Hit tank
				switch (coolPowerup.type) {
					case 1:
						tank.hp = TANK_INIT_HP;
						console.log("HP");
						break;
					case 2:
						tank.speed = 25;
						console.log("speed");
						break;
					case 3:
						tank.hp = 1;
						console.log("die");
						break;
				}
				powerup.dead = true;
			}
		});
	},
	//Detect if ball collides with any tank
	detectCollision: function(ball){
		var self = this;

		this.tanks.forEach( function(tank){
			if(tank.id != ball.ownerId
				&& Math.abs(tank.x - ball.x) < 30
				&& Math.abs(tank.y - ball.y) < 30){
				//Hit tank
				self.hurtTank(tank);
				ball.out = true;
				ball.exploding = true;
			}
		});
	},

	setHealth: function(tank, newHealth) {
		tank.hp = newHealth;
	},
	hurtTank: function(tank){
		tank.hp -= 10;
	},

	getData: function(){
		var gameData = {};
		gameData.tanks = this.tanks;
		gameData.balls = this.balls;
		gameData.powerup = this.powerup;

		return gameData;
	},

	cleanDeadTanks: function(){
		this.tanks = this.tanks.filter(function(t){
			return t.hp > 0;
		});
	},

	cleanDeadBalls: function(){
		this.balls = this.balls.filter(function(ball){
			return !ball.out;
		});
	},
	
	cleanpowerup: function(){
		this.powerup = this.powerup.filter(function(powerup){
			return !powerup.dead;
		});
	},

	increaseLastBallId: function(){
		this.lastBallId ++;
		if(this.lastBallId > 1000){
			this.lastBallId = 0;
		}
	}

}

var game = new GameServer();

/* Connection events */

io.on('connection', function(client) {
	console.log('User connected');

	client.on('joinGame', function(tank){
		console.log(tank.id + ' joined the game');
		var initX = getRandomInt(40, 900);
		var initY = getRandomInt(40, 500);
		client.emit('addTank', { id: tank.id, type: tank.type, isLocal: true, x: initX, y: initY, hp: TANK_INIT_HP });
		client.broadcast.emit('addTank', { id: tank.id, type: tank.type, isLocal: false, x: initX, y: initY, hp: TANK_INIT_HP} );
		game.addTank({ id: tank.id, type: tank.type, hp: TANK_INIT_HP});
	});

	client.on('sync', function(data){
		//Receive data from clients
		if(data.tank != undefined){
			game.syncTank(data.tank);
		}
		//update ball positions
		game.syncBalls();
		game.syncPowerup();
		//Broadcast data to clients
		client.emit('sync', game.getData());
		client.broadcast.emit('sync', game.getData());

		//I do the cleanup after sending data, so the clients know
		//when the tank dies and when the balls explode
		game.cleanDeadTanks();
		game.cleanDeadBalls();
		game.cleanpowerup();
		counter ++;
	});

	client.on('createPowerup', function(data) {
		game.addPowerup(data.powerup);
		client.emit('addPowerup', {id: data.powerup.id, x: data.powerup.x, y: data.powerup.y, dead: data.powerup.dead, superid: data.powerup.superid});
		client.broadcast.emit('addPowerup', {id: data.powerup.id, x: data.powerup.x, y: data.powerup.y, dead: data.powerup.dead, superid: data.powerup.superid});
	});

	client.on('shoot', function(ball){
		var ball = new Ball(ball.ownerId, ball.alpha, ball.x, ball.y );
		game.addBall(ball);
	});

	client.on('leaveGame', function(tankId){
		console.log(tankId + ' has left the game');
		game.removeTank(tankId);
		client.broadcast.emit('removeTank', tankId);
	});

});

function Ball(ownerId, alpha, x, y){
	this.id = game.lastBallId;
	game.increaseLastBallId();
	this.ownerId = ownerId;
	this.alpha = alpha; //angle of shot in radians
	this.x = x;
	this.y = y;
	this.out = false;
};

Ball.prototype = {

	fly: function(){
		//move to trajectory
		var speedX = BALL_SPEED * Math.sin(this.alpha);
		var speedY = -BALL_SPEED * Math.cos(this.alpha);
		this.x += speedX;
		this.y += speedY;
	}

}

function getRandomInt(min, max) {
	return Math.floor(Math.random() * (max - min)) + min;
}
